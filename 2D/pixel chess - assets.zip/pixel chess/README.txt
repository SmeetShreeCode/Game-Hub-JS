
//THANK U

Thank you for downloading my little chess project :) i really apreciate it, hope you like it and find it usefull
This is an individual project and may get some update in the future (depends on the feedback)
follow me on itch.io to stay tuned. @danimaccari -> https://dani-maccari.itch.io/


//HOW TO USE//

Pixel chess contains 2 type of pieces the 16x32p pack and the 16x16p and two colors for each one. A board and a pointer (mouse).

16x16p: Contains a sprite sheet for each color
16x32p: Contains a sprite sheet for each color + the individual sprite for each piece W(white) and B(black)
Extras: Contains 1 board (128x131p) w/ 3 color variations + one pointer (16x16p)


//LICENSE

This pack is free for personal use or comercial projects as long as it's atributed to DANI MACCARI.
You are free to edit the sprites as much as you want.
You may not repackage, redistribute or resell the assets, no matter how much they are modified. - This includes NFTs.